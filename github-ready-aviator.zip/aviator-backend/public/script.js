const statusDiv = document.getElementById("status");
statusDiv.innerText = "Game Loaded 🚀";