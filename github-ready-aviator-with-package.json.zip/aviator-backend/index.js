const express = require("express");
const http = require("http");
const fs = require("fs");
const { Server } = require("socket.io");
const cors = require("cors");
const jwt = require("jsonwebtoken");
const bcrypt = require("bcryptjs");

const authRoutes = require("./routes/auth");
const userRoutes = require("./routes/user");
const txRoutes = require("./routes/transactions");
const { router: adminRoutes, manualCrashPoint } = require("./routes/admin");

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: "*" } });

app.use(cors());
app.use(express.json());
app.use(express.static("public"));

app.use("/api/auth", authRoutes);
app.use("/api/user", userRoutes);
app.use("/api/tx", txRoutes);
app.use("/api/admin", adminRoutes);

function readUsers() {
  return JSON.parse(fs.readFileSync(__dirname + "/users.json"));
}
function writeUsers(data) {
  fs.writeFileSync(__dirname + "/users.json", JSON.stringify(data, null, 2));
}

function startGameLoop() {
  setInterval(() => {
    let crashPoint = manualCrashPoint || (Math.random() * 10 + 1);
    console.log("✈️ Crash at:", crashPoint.toFixed(2));
  }, 10000);
}

server.listen(3000, () => {
  console.log("✅ Server running on port 3000");
  startGameLoop();
});